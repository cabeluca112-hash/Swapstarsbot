#!/bin/bash
python swapstars_bot.py
